/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author ACER
 */
public class NAMESS {
    public static void main(String[] args) {
        int x[] = new int[5];
        x[0] = 666 ;
        x[1] = 777 ;
        x[2] = 888 ;
        x[3] = 999 ;
        x[4] = 555 ;
        x[5] = 444 ;
        System.out.println(x[0]);
        System.out.println(x[1]);
        System.out.println(x[2]);
        System.out.println(x[3]);
        System.out.println(x[4]);
        System.out.println(x[5]);
    } 
}    

